package Ex4DevOps;

public class Cliente {
    String nome;
    String email;
    int telefone;

    public Cliente(String nome, String email, int telefone) {
    }
}
