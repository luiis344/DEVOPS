package Ex4DevOps;

import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CadastroCliente status = new CadastroCliente("Nome", "Email", 0);
        while (true) {
            System.out.println("1- Adicionar cliente");
            System.out.println("2- Visualizar clientes");
            System.out.println("3- Atualizar cliente");
            System.out.println("4- Remover cliente");
            System.out.println("5- Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = sc.nextInt();
            sc.nextLine();

            if (opcao == 1) {
                System.out.print("Nome: ");
                String nome = sc.nextLine();
                System.out.print("Email: ");
                String email = sc.nextLine();
                System.out.print("Telefone: ");
                int telefone = sc.nextInt();
                sc.nextLine();

                status.adicionarCliente(new Cliente(nome, email, telefone));
            } else if (opcao == 2) {
                status.visualizarClientes();
            } else if (opcao == 3) {
                System.out.print("Digite o indice do cliente a ser atualizado: ");
                int index = sc.nextInt();
                sc.nextLine();

                System.out.print("Nome: ");
                String nome = sc.nextLine();
                System.out.print("Email: ");
                String email = sc.nextLine();
                System.out.print("Telefone: ");
                int telefone = sc.nextInt();
                sc.nextLine();
                status.atualizarCliente(index, new Cliente(nome, email, telefone));
            } else if (opcao == 4) {
                System.out.print("Dgite o indice do cliente a ser removido: ");
                int index = sc.nextInt();
                sc.nextLine();
                status.removerClientes(index);
            } else if (opcao == 5) {
                break;
            }
        }

    }

}


