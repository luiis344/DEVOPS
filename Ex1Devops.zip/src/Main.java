import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ScrumBoard scrumBoard = new ScrumBoard();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Adicionar tarefa");
            System.out.println("2. Visualizar tarefas");
            System.out.println("3. Marcar tarefa como concluída");
            System.out.println("4. Sair");
            System.out.print("Escolha uma opção: ");
            int option = scanner.nextInt();
            scanner.nextLine();

            if (option == 1) {
                System.out.print("Digite a descrição da tarefa: ");
                String taskDescription = scanner.nextLine();
                Task task = new Task(taskDescription);
                scrumBoard.addTask(task);
            } else if (option == 2) {
                scrumBoard.viewTasks();
            } else if (option == 3) {
                System.out.print("Digite o índice da tarefa que deseja marcar como concluída: ");
                int taskIndex = scanner.nextInt();
                scrumBoard.markTaskCompleted(taskIndex);
            } else if (option == 4) {
                break;
            } else {
                System.out.println("Opção inválida. Por favor, tente novamente.");
            }
        }
        scanner.close();
    }
}