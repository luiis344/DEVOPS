import java.util.ArrayList;

class ScrumBoard {
     ArrayList<Task> tasks;

     public ScrumBoard() {
          this.tasks = new ArrayList<>();
     }

     public void addTask(Task task) {
          this.tasks.add(task);
     }

     public void viewTasks() {
          for (int i = 0; i < tasks.size(); i++) {
               String status = tasks.get(i).completed ? "Concluída" : "Não concluída";
               System.out.println("Tarefa " + (i+1) + ": " + tasks.get(i).description + ", Status: " + status);
          }
     }

     public void markTaskCompleted(int taskIndex) {
          this.tasks.get(taskIndex).markAsCompleted();
     }
}
